import { pool } from '../db.js'


export const getSlider = async (req, res) => {
    const [rows] = await pool.query('select * from slider')
    res.json(rows)
}