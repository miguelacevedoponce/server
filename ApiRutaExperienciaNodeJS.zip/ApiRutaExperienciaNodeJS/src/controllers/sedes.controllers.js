import { pool } from '../db.js'


export const getSedes = async (req, res) => {
    const [rows] = await pool.query('select * from sedes')
    res.json(rows)
}

export const getSedesRandom = async (req, res) => {
    const [rows] = await pool.query('select * from sedes ORDER by RAND() limit 4')
    res.json(rows)
}

export const getSede = async (req, res) => {
    const [rows] = await pool.query('select * from sedes where id = ?',[req.params.id])
    res.json(rows[0])
}