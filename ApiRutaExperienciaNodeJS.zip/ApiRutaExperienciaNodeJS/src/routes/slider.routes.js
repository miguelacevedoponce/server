import { Router } from 'express'
import { getSlider } from '../controllers/slider.controllers.js'
const router = Router()

router.get('/slider',getSlider)


export default router